import os
from crewai import Crew, Process
from tasks import parse_task, compare_task, pr_task
from agents import code_parser_agent, comparator_agent, executor_agent

# 设置环境变量 (如果是真实运行需配置)
# os.environ["OPENAI_API_KEY"] = "your-api-key"

# 组装 Agent 协作网络
api_inspection_crew = Crew(
    agents=[code_parser_agent, comparator_agent, executor_agent],
    tasks=[parse_task, compare_task, pr_task],
    process=Process.sequential, # 按顺序流水线执行
    verbose=True
)

def run_inspection(controller_path: str, swagger_data: str):
    print(f"🚀 [CI/CD Hook] 开始拦截并巡检文件: {controller_path}")
    
    # 模拟 CI/CD 传入的上下文
    inputs = {
        'controller_file': controller_path,
        'swagger_spec_data': swagger_data
    }
    
    # 启动 Agent 组
    result = api_inspection_crew.kickoff(inputs=inputs)
    
    print("\n==========================================")
    print("✅ 自动化闭环执行结果 (PR 准备就绪)：")
    print("==========================================")
    print(result)

if __name__ == "__main__":
    # 模拟输入数据
    sample_controller_file = "src/controllers/OrderController.ts"
    sample_swagger_doc = "{ 'paths': { '/order': { 'post': { 'parameters': [] } } } }"
    
    run_inspection(sample_controller_file, sample_swagger_doc)
