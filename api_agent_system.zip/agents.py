import os
from crewai import Agent
from langchain_openai import ChatOpenAI

# 假设使用 OpenAI 兼容的 API，实际部署时可替换为团队内部的大模型服务
llm = ChatOpenAI(model="gpt-4-turbo", temperature=0.1)

# 1. 代码监听与解析器
code_parser_agent = Agent(
    role='高级 API 代码解析专家',
    goal='深度剖析网关及控制器层的路由、参数校验规则和业务层逻辑，提取真实代码特征',
    backstory='你是一个实时驻留在 CI/CD 流程中的静态分析与代码理解引擎。你极其细致，擅长将复杂的业务逻辑和路由控制器代码抽象为标准化的接口特征字典。',
    verbose=True,
    allow_delegation=False,
    llm=llm
)

# 2. 智能比对引擎
comparator_agent = Agent(
    role='API 契约比对推理引擎',
    goal='将代码真实逻辑转化为格式化特征，与现有的 Swagger/Postman 文档进行长链推理与交叉检索，精准定位差异',
    backstory='你是 API 文档规范的守护者。你擅长进行 JSON/YAML 数据结构的交叉比对，拥有强大的逻辑推理能力，能敏锐地发现字段遗漏、类型不匹配或废弃接口。',
    verbose=True,
    allow_delegation=False,
    llm=llm
)

# 3. 自动化闭环执行器
executor_agent = Agent(
    role='CI/CD 自动化 PR 执行器',
    goal='根据差异报告，自动生成 PR（包含文档修改建议、最新测试示例和 Mock 样本数据）',
    backstory='你精通 Git 工作流和 API 契约闭环。你不仅能指出问题，还能直接产出修复方案和 Mock 数据，大幅降低研发人员的维护成本。',
    verbose=True,
    allow_delegation=False,
    llm=llm
)
