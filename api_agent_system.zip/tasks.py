from crewai import Task
from agents import code_parser_agent, comparator_agent, executor_agent

# 任务 1：拦截与解析代码
parse_task = Task(
    description=(
        '拦截最新的 Git Commit。读取文件 {controller_file} 的源代码。'
        '请深度解析该控制器中的路由路径、HTTP 方法、请求头、Query 参数、Body 结构以及返回值类型。'
    ),
    expected_output='一段结构化的 JSON 格式的“代码真实逻辑”特征提取报告。',
    agent=code_parser_agent
)

# 任务 2：文档交叉检索与比对
compare_task = Task(
    description=(
        '读取现有的规范文档库数据：{swagger_spec_data}。'
        '利用上一步生成的“代码真实逻辑”特征，进行交叉比对。找出代码真实实现与文档描述之间的所有差异（包含字段缺失、类型不匹配、必填项错误等）。'
    ),
    expected_output='一份详尽的 API 差异报告。如果完全一致，则输出"契约一致"。',
    agent=comparator_agent
)

# 任务 3：生成闭环 PR 及 Mock 数据
pr_task = Task(
    description=(
        '基于上一步的差异报告，执行以下自动化操作：\n'
        '1. 生成用于更新 Swagger/OpenAPI 的 JSON/YAML 修正补丁。\n'
        '2. 基于新的字段和类型，顺带生成一组最新的 JSON Mock 样本数据和测试用例。\n'
        '3. 组装一个完整的 Pull Request 标题和正文描述。'
    ),
    expected_output='标准的 GitHub Pull Request Markdown 模板，包含更新的代码片段、Mock 数据以及修复说明。',
    agent=executor_agent
)
