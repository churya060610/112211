from crewai import Task
from agents import topology_parser_agent, security_contract_agent, ecosystem_executor_agent, dx_insights_agent

# 任务 1: 语义与拓扑提取
parse_topology_task = Task(
    description=(
        '分析以下目标源代码 (例如 Java/Spring Boot 或 TS/NestJS)：\n\n{source_code}\n\n'
        '请提取：1. 路由路径与 HTTP 方法。 2. 数据传输对象(DTO)的字段与类型。 '
        '3. 权限鉴定注解（如 RBAC 策略）。 4. 代码中体现的下游服务调用依赖。'
    ),
    expected_output='一份结构化的 JSON 报告，包含 API 路由、参数、权限要求及拓扑依赖。',
    agent=topology_parser_agent
)

# 任务 2: 契约与安全诊断
diagnostic_security_task = Task(
    description=(
        '读取现有旧版文档：\n\n{swagger_doc}\n\n'
        '利用上一步的特征特征进行深入比对。'
        '要求：1. 找出字段和类型的差异。 2. 判定本次更新是否为破坏性变更 (Breaking Change, 如删除了必需字段)。'
        '3. 审查是否存在敏感数据暴露或鉴权缺失的风险。'
    ),
    expected_output='详细的 API 契约与安全诊断报告，明确标记出 风险等级(高/中/低)。',
    agent=security_contract_agent
)

# 任务 3: 生态闭环与基建产出
auto_remediation_task = Task(
    description=(
        '基于诊断报告，生成可直接落地的闭环基建产物：\n'
        '1. 更新后的 OpenAPI YAML/JSON 片段。\n'
        '2. 一套覆盖边缘情况的 Mock JSON 数据。\n'
        '3. 为前端团队生成对应的 TypeScript SDK 接口定义 (interface) 及调用函数草案。'
    ),
    expected_output='闭环交付物合集：修复 Patch、Mock 数据、TS SDK 代码草案以及 PR 描述正文。',
    agent=ecosystem_executor_agent
)

# 任务 4: 研发效能与通知大盘
dx_report_task = Task(
    description=(
        '整合所有变更和产出，生成一份格式友好的 Markdown API 变更日志 (Changelog)。\n'
        '包含：变更概览、安全审计结论、前端联调指南，并附带一句针对团队研发效能的提升鼓励话语。'
    ),
    expected_output='用于钉钉/企微/Slack webhook 推送的 Markdown 格式通知文案。',
    agent=dx_insights_agent
)
