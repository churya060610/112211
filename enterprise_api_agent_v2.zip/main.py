import os
from crewai import Crew, Process
from tasks import parse_topology_task, diagnostic_security_task, auto_remediation_task, dx_report_task
from agents import topology_parser_agent, security_contract_agent, ecosystem_executor_agent, dx_insights_agent

# 组装 4 个 Agent 的流水线
enterprise_api_crew = Crew(
    agents=[topology_parser_agent, security_contract_agent, ecosystem_executor_agent, dx_insights_agent],
    tasks=[parse_topology_task, diagnostic_security_task, auto_remediation_task, dx_report_task],
    process=Process.sequential, 
    verbose=True
)

def run_enterprise_inspection():
    # 模拟 CI/CD 抓取到的 Java Spring Boot 控制器代码
    sample_code = """
    @RestController
    @RequestMapping("/api/v2/orders")
    public class OrderController {
        
        @PreAuthorize("hasRole('ADMIN_FINANCE')")
        @PostMapping("/adjustAmount")
        public OrderResponse adjustAmount(@Valid @RequestBody AdjustAmountDto dto) {
            // 调用了内部支付网关 RPC
            paymentGatewayRpc.processAdjustment(dto.getOrderId(), dto.getNewAmount());
            return new OrderResponse(dto.getOrderId(), "SUCCESS", dto.getNewAmount());
        }
    }
    """
    
    # 模拟现有的 Swagger 契约 (存在滞后和差异)
    sample_swagger = """{
        "paths": {
            "/api/v2/orders/adjustAmount": {
                "post": {
                    "summary": "旧版金额调整接口",
                    "security": [],
                    "parameters": []
                }
            }
        }
    }"""

    inputs = {
        'source_code': sample_code,
        'swagger_doc': sample_swagger
    }

    print("==================================================")
    print("🚀 [CI/CD Pipeline] 触发企业级 API 治理流水线 v2.0")
    print("==================================================")
    
    # 启动多 Agent 协作
    result = enterprise_api_crew.kickoff(inputs=inputs)
    
    print("\n==================================================")
    print("✅ 闭环执行完毕，最终大盘报告与交付物：")
    print("==================================================")
    print(result)

if __name__ == "__main__":
    # 配置你的大模型 API 密钥
    # os.environ["OPENAI_API_KEY"] = "sk-xxxxxx"
    run_enterprise_inspection()
